$(function() {
      $('#fds img').each(function(i) {
    $(this).delay((i++) * 100).fadeTo(1000, 1); })
}); 