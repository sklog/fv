<script type="text/javascript">
$(document).ready(function() {
setTimeout ("$('.window_show').show('drop');", 1000);
});
</script>