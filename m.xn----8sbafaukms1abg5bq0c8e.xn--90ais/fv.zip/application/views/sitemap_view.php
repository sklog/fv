<div class="ramka_3"><div class="m"><h2 class="house-header">Карта сайта</h2><hr size="2" color="orange"><br>
<ul>
	<li><a class="text_sitemap" href="/" title="Главная">Главная</a></li>
	<li><a class="text_sitemap" href="/foto" title="Фото">Фото</a></li>
	<li><a class="text_sitemap" href="/price" title="Цены">Цены</a></li>
	<li><a class="text_sitemap" href="/schetchiki" title="Счетчики воды. Установка и замена">Счетчики воды. Установка и замена</a></li>
	<li><a class="text_sitemap" href="/radiatory" title="Замена радиаторов отопления">Замена радиаторов отопления</a></li>
	<li><a class="text_sitemap" href="/trybi" title="Замена труб водоснабжения и канализации">Замена труб водоснабжения и канализации</a></li>
	<li><a class="text_sitemap" href="/polotencesyshitel" title="Установка полотенцесушителя">Установка полотенцесушителя</a></li>
	<li><a class="text_sitemap" href="/pol" title="Установка теплого пола">Установка теплого пола</a></li>
	<li><a class="text_sitemap" href="/smesitel" title="Установка смесителя">Установка смесителя</a></li>
	<li><a class="text_sitemap" href="/dyshevaia" title="Установка душевой кабины">Установка душевой кабины</a></li>
	<li><a class="text_sitemap" href="/vodonagrevatel" title="Установка водонагревателя">Установка водонагревателя</a></li>
	<li><a class="text_sitemap" href="/ynitaz" title="Установка унитаза">Установка унитаза</a></li>
	<li><a class="text_sitemap" href="/vanna" title="Установка ванны, умывальника">Установка ванны, умывальника</a></li>
</ul>
</div></div><br>
