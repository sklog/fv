<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js'></script>
<script type='text/javascript' src='/js/send.js'></script>
<script type='text/javascript' src='/js/in.js'></script>

<div class='window_show green'>
    Ваш номер телефона:<br><br>
    <form action="telefon" method="POST">
        <div id="resp"></div>
        <input id="phone" type="text" value="+375" name="telefon"><br><br>
        <input class="but_call" name="sub" type="submit" value="Перезвоните мне!">
    </form>
</div>






<h1 class="t1">Услуги сантехника:</h1>
<div id="fds">
<table style="width: 100%;">
  <tbody>
      <tr>
      <td><a class="text_ramka" href="schetchiki"><div class="ramka">Счетчики воды. Установка и замена<img class="swf" src="/images/schetchiki.gif" width="115" height="60"></div></a></td>
      <td><a class="text_ramka" href="radiatory"><div class="ramka">Замена радиаторов отопления<img class="swf" src="/images/radiator.gif" width="80" height="60"></div></a></td>
      <td><a class="text_ramka" href="trybi"><div class="ramka">Замена труб водоснабжения и канализации<img class="swf" src="/images/trybi.gif" width="80" height="61"></div></a></td>
      <td><a class="text_ramka" href="polotencesyshitel"><div class="ramka">Установка полотенцесушителя<img class="swf" src="/images/polotence.gif" width="55" height="75"></div></a></td>
      <td><a class="text_ramka" href="pol"><div class="ramka">Установка теплого пола<img class="swf" src="/images/pol.gif" width="95" height="79"></div></a></td>
    </tr>
    <tr>
      <td><a class="text_ramka" href="smesitel"><div class="ramka">Установка смесителя<img class="swf" src="/images/smesitel.gif" width="90" height="60"></div></a></td>
      <td><a class="text_ramka" href="dyshevaia"><div class="ramka">Установка душевой кабины<img class="swf" src="/images/dyshevaia.gif" width="60" height="76"></div></a></td>
      <td><a class="text_ramka" href="vodonagrevatel"><div class="ramka">Установка водонагревателя<img class="swf" src="/images/vodonagrevatel.gif" width="40" height="73"></div></a></td>
      <td><a class="text_ramka" href="ynitaz"><div class="ramka">Установка унитаза<img class="swf" src="/images/ynitaz.gif" width="65" height="75"></div></a></td>
      <td><a class="text_ramka" href="vanna"><div class="ramka">Установка ванны, умывальника<img class="swf" src="/images/vanna.gif" width="80" height="65"></div></a></td>
    </tr>
  </tbody>
</table>
</div>


<img class="menu_back_2" src="/images/footer_3.jpg"/>
<h2 class="t2">Наши клиенты:</h2>
<table class="table_2"> 
  <tbody>
    <tr valign="top">
      <td class="text_ramka"><div class="ramka_2">Бизнес-центр<br>«Sky Towers»<br><br><img alt="Skytowers" class="img_k"src="/images/skytowers.jpg" ></div></td>
      <td class="text_ramka"><div class="ramka_2">Бизнес-центр<br>«ПОРТ»<br><br><img alt="Порт" class="img_k"src="/images/port.jpg" ></div></td>
      <td class="text_ramka"><div class="ramka_2">Торговый центр<br>«Гиппо»<br><br><img alt="Гиппо" class="img_k"src="/images/gippo.jpg" ></div></td>
      <td class="text_ramka"><div class="ramka_2">Коттеджный пос.<br>«Радужный»<br><br><img alt="kottedji" class="img_k"src="/images/kottedji.jpg" ></div></td>
      <td class="text_ramka"><div class="ramka_2">ОАО<br>«Франсабанк»<br><br><img alt="bank" class="img_k"src="/images/bank.jpg" ></div></td>
    </tr>
  </tbody>
</table>
<table class="table_3"> 
  <tbody>
    <tr valign="top">
      <td style="width:10px;"></td>
      <td class="table_3_in">

<table style="width:100%;" border="0">
  <tr>
    <td>
  <h2 class="t3">О нас:</h2><br>
<p><strong>Вам срочно понадобилась замена смесителя, демонтаж унитаза или установка ванны, и вы хотите недорого провести сантехнические работы?
Сколько же стоит вызов мастера в Минске?</strong></p><br>
<p>Проводить установку, замену или ремонт сантехники будет настоящий профессионал в этом деле, что гарантирует вам высокое качество работы!</p><br>
<p>Вы можете быть уверены в решении поставленных задач, ведь наши мастера имеют огромный опыт в этой сфере с 2006 года и положительные отзывы клиентов.</p><br>
<p>Ознакомьтесь с ценами на услуги в прайс-листе.</p><br>
<p><strong>Почему вызвать сантехника на дом выгодней у нас, а не из жэка?</strong></p><br>
<p>Обратившись к нам вы можете найти и сделать <strong>бесплатный вызов</strong> мастера в любое удобное для вас время.</p><br>
<p>Работа сантехников осуществляется <strong>круглосуточно</strong>.</p>

    </td>
    <td style="text-align:center">
<img alt="Skytowers" style="widht:50px;height:160px"  src="/images/cena.png" >
<img alt="Skytowers" style="widht:160px;height:160px"  src="/images/kachestvo.png" >
    </td>
  </tr>
</table>
  
      </td>
      <td style="width:10px"></td>
   </tr>
  </tbody>
</table>
