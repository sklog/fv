<link rel="stylesheet" type="text/css" href="/images/gallery/fancybox/jquery.fancybox.css">
<script type="text/javascript" src="/images/gallery/fancybox/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="/images/gallery/fancybox/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/images/gallery/fancybox/jquery.fancybox-1.2.1.pack.js"></script>
<script type="text/javascript">
$(document).ready(function() { 
$("a.first").fancybox(); 
$("a.two").fancybox(); 
$("a.video").fancybox({"frameWidth":520,"frameHeight":400}); 
$("a.content").fancybox({"frameWidth":600,"frameHeight":300}); 
});
</script>
<div align="center">
<a class="two" rel="group" href="images/gallery/IMG_1.JPG"><img class="image" src="images/gallery/IMG_1.JPG"></a>
<a class="two" rel="group" href="images/gallery/IMG_2.JPG"><img class="image" src="images/gallery/IMG_2.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_3.JPG"><img class="image" src="images/gallery/IMG_3.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_4.JPG"><img class="image" src="images/gallery/IMG_4.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_5.JPG"><img class="image" src="images/gallery/IMG_5.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_6.JPG"><img class="image" src="images/gallery/IMG_6.JPG" /></a>
<a class="two" rel="group" href="images/gallery/IMG_7.JPG"><img class="image" src="images/gallery/IMG_7.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_9.JPG"><img class="image" src="images/gallery/IMG_9.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_10.JPG"><img class="image" src="images/gallery/IMG_10.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_11.JPG"><img class="image" src="images/gallery/IMG_11.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_12.JPG"><img class="image" src="images/gallery/IMG_12.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_13.JPG"><img class="image" src="images/gallery/IMG_13.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_14.JPG"><img class="image" src="images/gallery/IMG_14.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_15.JPG"><img class="image" src="images/gallery/IMG_15.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_16.JPG"><img class="image" src="images/gallery/IMG_16.JPG" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_17.jpg"><img class="image" src="images/gallery/IMG_17.jpg" /></a>
<a class="two" rel="group"  href="images/gallery/IMG_18.jpg"><img class="image" src="images/gallery/IMG_18.jpg" /></a>
</div>