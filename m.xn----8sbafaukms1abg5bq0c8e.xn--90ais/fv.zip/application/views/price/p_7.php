<div class="m"><h2 class="house-header">СТОИМОСТЬ УСТАНОВКИ ДУШЕВЫХ КАБИН</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;height:600px" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
     <tr>
      <td><p class="m">Установка ванных шторок</p></td>
      <td><p class="m">400 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевой панели (стойки)</p></td>
      <td><p class="m">500 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевого бокса от 120см (без пара и гидр.масс.)</p></td>
      <td><p class="m">800 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Установка душевого уголка (поддон + шторки)</p></td>
      <td><p class="m">1 000 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Установка душевой кабины (80-120 см) без пара</p></td>
      <td><p class="m">1 300 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевой кабины (80-120 см) с парогенератором</p></td>
      <td><p class="m">1 500 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевой кабины (80-120 см) с финской сауной</p></td>
      <td><p class="m">1 800 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевого бокса от 120 см.с паром, без гидромассажа</p></td>
      <td><p class="m">2 100 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка душевого бокса от 120 см с паром и гидромассажем</p></td>
      <td><p class="m">2 500 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>