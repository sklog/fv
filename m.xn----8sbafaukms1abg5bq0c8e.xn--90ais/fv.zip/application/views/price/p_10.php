<div class="m"><h2 class="house-header">СТОИМОСТЬ УСТАНОВКИ ВАНН, УМЫВАЛЬНИКОВ</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
    <tr>
      <td><p class="m">Установка акриловой ванны без экрана</p></td>
      <td><p class="m">700 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Установка акриловой ванны с экраном</p></td>
      <td><p class="m">990 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка чугунной ванны</p></td>
      <td><p class="m">700 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Подключение стиральной машины</p></td>
      <td><p class="m">200 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Установка и подключение умывальника</p></td>
      <td><p class="m">600 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>