<div class="m"><h2 class="house-header">СТОИМОСТЬ УСТАНОВКИ СМЕСИТЕЛЯ</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;height:270px" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
    <tr>
      <td><p class="m">Установка смесителя на умывальник, ванну, кухонную мойку</p></td>
      <td><p class="m">200 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>