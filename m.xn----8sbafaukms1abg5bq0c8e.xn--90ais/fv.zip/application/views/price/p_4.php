<div class="m"><h2 class="house-header">СТОИМОСТЬ УСТАНОВКИ ПОЛОТЕНЦЕСУШИТЕЛЯ</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;height:300px" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
    <tr>
      <td><p class="m">Навеска полотенцесушителя</p></td>
      <td><p class="m">400 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Монтаж полотенцесушителя (змеевика) с заменой труб и перемычкой, без переноса</p></td>
      <td><p class="m">1 200 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Монтаж полотенцесушителя (змеевика) с заменой труб и перемычкой, с переносом</p></td>
      <td><p class="m">1 400 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>