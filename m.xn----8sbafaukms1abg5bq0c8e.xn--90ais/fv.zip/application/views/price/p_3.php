<div class="m"><h2 class="house-header">СТОИМОСТЬ МОНТАЖА ТОЧКИ ВОДОСНАБЖЕНИЯ И КАНАЛИЗАЦИИ</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
       <tr>
      <td><p class="m">Точка водопровод + канализация (подвод  всех труб к одному сантех. прибору)</p></td>
      <td><p class="m">500 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Штроба в бетоне, кирпиче (под водопровод)</p></td>
      <td><p class="m">100 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Штроба в бетоне, кирпиче (под канализацию 50)</p></td>
      <td><p class="m">200 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Штроба (газосиликатный блок)</p></td>
      <td><p class="m">60 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Монтаж фильтр тонкой очистки</p></td>
      <td><p class="m">600 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>