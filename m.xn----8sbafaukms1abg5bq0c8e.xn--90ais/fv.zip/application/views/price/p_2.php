<div class="m"><h2 class="house-header">СТОИМОСТЬ РАБОТ ПО ЗАМЕНЕ РАДИАТОРОВ</h2><hr size="2" color="orange"><br>
<div class="castom">
<table class="tab" style="text-align: left; width: 100%;" border="1"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="background-color:AliceBlue;width:80%;height:70px"><p class="m">Название услуги</p></td>
      <td style="background-color:AliceBlue"><p class="m">Цена</p></td>
    </tr>
    <tr>
      <td><p class="m">Перенос/замена и подключение радиатора отопления в квартире</p></td>
      <td><p class="m">1 200 000</p></td>
    </tr>
    <tr>
      <td><p class="m">Точка отопления</p></td>
      <td><p class="m">900 000</p></td>
    </tr>
     <tr>
      <td><p class="m">Подключение коллектора (гребенки)</p></td>
      <td><p class="m">900 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Обвязка котла</p></td>
      <td><p class="m">230 000</p></td>
    </tr>
        <tr>
      <td><p class="m">Прокладка стояков,  за 1 пог.м</p></td>
      <td><p class="m">60 000</p></td>
    </tr>
  </tbody>
</table>
</div>
</div><br>