<?php
include_once("dopmenu_view.php");
?>
<div class="ramka_3">
<?php
include_once("price/p_1.php");
?>
</div>