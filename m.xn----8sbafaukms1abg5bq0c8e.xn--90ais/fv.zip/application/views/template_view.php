<html lang="ru">
<head>
	<link rel="stylesheet" type="text/css" href="/css/css.css" />
	<meta charset="utf-8">
	<title>Вызвать сантехника на дом в Минске недорого</title>
	<meta name="description" content="Сантехник работает круглосуточно. Срочный и бесплантный вызов на дом, для осмотра сантехники, в Минске.Узнать цены и стоимость можно в прайс листе.">
</head>
<body>
	<table class="menu">
		<tr>
		<td><a class="text_menu" href="/">Вызов-сантехника.бел</a></td>
		<td><a class="text_menu" href="/">Главная</a></td>
		<td><a class="text_menu" href="foto">Фото</a></td>
		<td><a class="text_menu" href="price"><strong>Цены</strong></a></td>
		<td style="width:500px"><div class="text_menu" style="margin-left:150px">Телефон: МТС +37533 352 74 30</div></td>
	</tr>
	</table>
	<img class="menu_back"src="/images/plumbing.jpg" >
	<?php include 'application/views/'.$content_view; ?>
<div class="bottom">
	<div  class="text_menu">© 2006 - 2016
	<a  class="text_menu" href="/sitemap">Карта сайта</a></div>
</div>
</body>
</html>
