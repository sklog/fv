<?php
class Controller_trybi extends Controller
{
	function action_index()
	{
		$this->view->generate('trybi_view.php','template_view.php');

	}
}



?>